module.exports = {
  NODE_ENV: (process.env.NODE_ENV || 'development'),
  PORT: (process.env.PORT || 1414),
  TESTING_PORT: (process.env.PORT || 4432)
};
